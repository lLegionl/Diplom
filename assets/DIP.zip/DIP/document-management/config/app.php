<?php
return [
    'app_name' => 'DOCFLOW',
    'base_url' => 'http://document-management',
    'upload_dir' => __DIR__ . '/../public/uploads/',
    'controllers_dir' => __DIR__ . '/../app/controllers/',
    'views_dir' => __DIR__ . '/../views/'
];