        </main>
    </div>
    
    <script src="/public/assets/js/main.js"></script>
</body>
</html>