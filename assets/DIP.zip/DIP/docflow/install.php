<?php
require_once 'config.php';

// Проверяем, не установлена ли уже система
try {
    $pdo->query("SELECT 1 FROM users LIMIT 1");
    die("Система уже установлена. Удалите install.php в целях безопасности.");
} catch (PDOException $e) {
    // Продолжаем установку
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admin_username = sanitize($_POST['admin_username']);
    $admin_password = sanitize($_POST['admin_password']);
    $admin_email = sanitize($_POST['admin_email']);
    $admin_name = sanitize($_POST['admin_name']);
    
    if (empty($admin_username) || empty($admin_password) || empty($admin_email) || empty($admin_name)) {
        $error = "Все поля обязательны для заполнения";
    } elseif (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
        $error = "Введите корректный email адрес";
    } else {
        try {
            // Создаем таблицы
            $pdo->exec("
                CREATE TABLE users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(50) NOT NULL UNIQUE,
                    password VARCHAR(255) NOT NULL,
                    full_name VARCHAR(100) NOT NULL,
                    email VARCHAR(100) NOT NULL UNIQUE,
                    role ENUM('admin', 'user', 'manager') DEFAULT 'user',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_login TIMESTAMP NULL
                )
            ");
            
            $pdo->exec("
                CREATE TABLE documents (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    doc_number VARCHAR(50) NOT NULL UNIQUE,
                    title VARCHAR(255) NOT NULL,
                    doc_type ENUM('Договор', 'Приказ', 'Заявление', 'Счет', 'Акт') NOT NULL,
                    description TEXT,
                    file_path VARCHAR(255),
                    status ENUM('Черновик', 'На согласовании', 'Утвержден', 'Отклонен', 'Архив') DEFAULT 'Черновик',
                    created_by INT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP NULL,
                    FOREIGN KEY (created_by) REFERENCES users(id)
                )
            ");
            
            $pdo->exec("
                CREATE TABLE tasks (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(255) NOT NULL,
                    description TEXT,
                    assigned_to INT NOT NULL,
                    created_by INT NOT NULL,
                    due_date DATE,
                    status ENUM('Новая', 'В работе', 'Завершена', 'Отменена') DEFAULT 'Новая',
                    priority ENUM('Низкий', 'Средний', 'Высокий') DEFAULT 'Средний',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (assigned_to) REFERENCES users(id),
                    FOREIGN KEY (created_by) REFERENCES users(id)
                )
            ");
            
            // Создаем администратора
            $hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("
                INSERT INTO users 
                (username, password, full_name, email, role) 
                VALUES (?, ?, ?, ?, 'admin')
            ");
            $stmt->execute([$admin_username, $hashed_password, $admin_name, $admin_email]);
            
            // Создаем папку для загрузок
            if (!is_dir(UPLOAD_DIR)) {
                mkdir(UPLOAD_DIR, 0755, true);
            }
            
            // Удаляем install.php в целях безопасности
            unlink(__FILE__);
            
            header('Location: login.php');
            exit();
        } catch (PDOException $e) {
            $error = "Ошибка установки: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Установка системы документооборота</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Стили аналогичные login.php */
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1><i class="fas fa-file-alt"></i> DOCFLOW</h1>
            <p>Установка системы электронного документооборота</p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label class="form-label">Имя пользователя администратора</label>
                <input type="text" name="admin_username" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Пароль администратора</label>
                <input type="password" name="admin_password" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Email администратора</label>
                <input type="email" name="admin_email" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">ФИО администратора</label>
                <input type="text" name="admin_name" class="form-control" required>
            </div>
            
            <button type="submit" class="btn">
                <i class="fas fa-cogs"></i> Установить систему
            </button>
        </form>
    </div>
</body>
</html>