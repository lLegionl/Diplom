<?php
require_once 'config.php';
requireLogin();

$user = currentUser();

// Получаем последние документы
try {
    $stmt = $pdo->prepare("
        SELECT d.*, u.full_name as creator 
        FROM documents d
        JOIN users u ON d.created_by = u.id
        ORDER BY d.created_at DESC
        LIMIT 5
    ");
    $stmt->execute();
    $documents = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Ошибка при получении документов: " . $e->getMessage());
}

// Получаем количество задач
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as task_count FROM tasks WHERE assigned_to = ? AND status != 'Завершена'");
    $stmt->execute([$user['id']]);
    $task_count = $stmt->fetch()['task_count'];
} catch (PDOException $e) {
    $task_count = 0;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная | <?php echo APP_NAME; ?></title>
    <style>
        /* Основные цвета */
        :root {
            --dark-blue: #0a192f;     /* Основной темно-синий */
            --navy: #172a45;          /* Для навигации */
            --light-blue: #64ffda;    /* Акцентный бирюзовый */
            --text-light: #ccd6f6;    /* Светлый текст */
            --text-dark: #8892b0;     /* Серо-синий текст */
        }
        
        /* Сброс стилей и базовые настройки */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: var(--dark-blue);
            color: var(--text-light);
            line-height: 1.6;
        }
        
        /* Шапка */
        header {
            background-color: var(--navy);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        
        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--light-blue);
        }
        
        /* Основной контейнер */
        .container {
            display: flex;
            min-height: calc(100vh - 60px);
        }
        
        /* Боковая панель */
        .sidebar {
            width: 250px;
            background-color: var(--navy);
            padding: 1.5rem;
            border-right: 1px solid rgba(100, 255, 218, 0.1);
        }
        
        .nav-menu {
            list-style: none;
            margin-top: 2rem;
        }
        
        .nav-item {
            margin-bottom: 1rem;
            position: relative;
        }
        
        .nav-link {
            color: var(--text-light);
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 0.5rem;
            border-radius: 4px;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .nav-link:hover {
            background-color: rgba(100, 255, 218, 0.1);
            color: var(--light-blue);
        }
        
        .nav-link i {
            margin-right: 10px;
            color: var(--light-blue);
        }
        
        /* Выпадающее меню */
        .dropdown-menu {
            display: none;
            list-style: none;
            margin-left: 1.5rem;
            margin-top: 0.5rem;
            border-left: 2px solid var(--light-blue);
            padding-left: 1rem;
        }
        
        .dropdown-menu li {
            margin-bottom: 0.5rem;
        }
        
        .dropdown-menu a {
            color: var(--text-dark);
            text-decoration: none;
            display: block;
            padding: 0.3rem 0.5rem;
            border-radius: 3px;
            transition: all 0.2s ease;
        }
        
        .dropdown-menu a:hover {
            color: var(--light-blue);
            background-color: rgba(100, 255, 218, 0.1);
        }
        
        .active .dropdown-menu {
            display: block;
        }
        
        .active > .nav-link {
            color: var(--light-blue);
            font-weight: 600;
        }
        
        /* Основное содержимое */
        .main-content {
            flex: 1;
            padding: 2rem;
        }
        
        /* Карточки */
        .card {
            background-color: var(--navy);
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border: 1px solid rgba(100, 255, 218, 0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid rgba(100, 255, 218, 0.2);
        }
        
        .card-title {
            color: var(--light-blue);
            font-size: 1.2rem;
        }
        
        /* Кнопки */
        .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            background-color: var(--light-blue);
            color: var(--dark-blue);
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .btn:hover {
            background-color: rgba(100, 255, 218, 0.8);
            transform: translateY(-2px);
        }
        
        /* Таблица документов */
        .doc-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .doc-table th, .doc-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid rgba(100, 255, 218, 0.1);
        }
        
        .doc-table th {
            color: var(--light-blue);
            font-weight: 600;
        }
        
        /* Статусы документов */
        .status {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending {
            background-color: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }
        
        .status-approved {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .status-draft {
            background-color: rgba(108, 117, 125, 0.1);
            color: #6c757d;
        }
        
        .status-rejected {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .status-archive {
            background-color: rgba(111, 66, 193, 0.1);
            color: #6f42c1;
        }
    </style>
    <!-- Иконки Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Шапка -->
    <header>
        <div class="logo"><?php echo APP_NAME; ?></div>
        <div>
            <span style="margin-right: 1rem;"><?php echo htmlspecialchars($user['full_name']); ?> (<?php echo htmlspecialchars($user['role']); ?>)</span>
            <i class="fas fa-bell" style="color: var(--light-blue); margin-right: 1rem;"></i>
            <a href="logout.php" style="color: var(--light-blue); text-decoration: none;">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </header>
    
    <!-- Основной контейнер -->
    <div class="container">
        <!-- Боковая панель -->
        <aside class="sidebar">
            <ul class="nav-menu">
                <li class="nav-item" id="documents-menu">
                    <div class="nav-link">
                        <i class="fas fa-file-alt"></i>
                        Документы
                        <i class="fas fa-chevron-down" style="margin-left: auto; font-size: 0.8rem;"></i>
                    </div>
                    <ul class="dropdown-menu">
                        <li><a href="#"><i class="fas fa-inbox"></i> Входящие</a></li>
                        <li><a href="#"><i class="fas fa-paper-plane"></i> Исходящие</a></li>
                        <li><a href="#"><i class="fas fa-file-signature"></i> Внутренние</a></li>
                        <li><a href="#"><i class="fas fa-archive"></i> Архив</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="fas fa-tasks"></i>
                        Задачи
                        <?php if ($task_count > 0): ?>
                            <span style="margin-left: auto; background: var(--light-blue); color: var(--dark-blue); border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 0.7rem;"><?php echo $task_count; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="fas fa-calendar-alt"></i>
                        Календарь
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Отчеты
                    </a>
                </li>
                <?php if ($user['role'] === 'admin'): ?>
                <li class="nav-item">
                    <a href="admin/" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Администрирование
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </aside>
        
        <!-- Основное содержимое -->
        <main class="main-content">
            <!-- Карточка быстрых действий -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Быстрые действия</h2>
                </div>
                <div>
                    <a href="create_document.php" class="btn" style="margin-right: 10px;">
                        <i class="fas fa-plus"></i> Создать документ
                    </a>
                    <a href="upload.php" class="btn">
                        <i class="fas fa-upload"></i> Загрузить файл
                    </a>
                </div>
            </div>
            
            <!-- Карточка последних документов -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Последние документы</h2>
                    <a href="documents.php" style="color: var(--light-blue); text-decoration: none; font-size: 0.9rem;">Все документы →</a>
                </div>
                <table class="doc-table">
                    <thead>
                        <tr>
                            <th>Номер</th>
                            <th>Название</th>
                            <th>Тип</th>
                            <th>Дата</th>
                            <th>Статус</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($documents as $doc): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($doc['doc_number']); ?></td>
                            <td><?php echo htmlspecialchars($doc['title']); ?></td>
                            <td><?php echo htmlspecialchars($doc['doc_type']); ?></td>
                            <td><?php echo date('d.m.Y', strtotime($doc['created_at'])); ?></td>
                            <td>
                                <?php 
                                    $status_class = 'status-' . strtolower(str_replace(' ', '-', $doc['status']));
                                    echo '<span class="status ' . $status_class . '">' . $doc['status'] . '</span>';
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <script>
        // Обработчик для выпадающего меню документов
        document.getElementById('documents-menu').addEventListener('click', function(e) {
            // Предотвращаем переход по ссылке если кликнули на сам пункт меню
            if (e.target.tagName !== 'A') {
                this.classList.toggle('active');
                
                // Поворачиваем иконку стрелки
                const icon = this.querySelector('.fa-chevron-down');
                if (this.classList.contains('active')) {
                    icon.style.transform = 'rotate(180deg)';
                } else {
                    icon.style.transform = 'rotate(0deg)';
                }
            }
        });
        
        // Закрываем меню при клике вне его
        document.addEventListener('click', function(e) {
            const documentsMenu = document.getElementById('documents-menu');
            if (!documentsMenu.contains(e.target)) {
                documentsMenu.classList.remove('active');
                documentsMenu.querySelector('.fa-chevron-down').style.transform = 'rotate(0deg)';
            }
        });
    </script>
</body>
</html>